﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFAlytalo
{
    public class Sauna
    {
        public Boolean Switched { get; set; }
        public int Heat { get; set; }
        public void TurnOn() // toimii kuin kiihdytä nappi ajastimen kanssa
        {
            Switched = true;
            Heat++;
        }
        public void TurnOff()
        {
            Switched = false;
            Heat--;
        }
        // OPETTAJALLE: Taistelin yli viikon verran tuon saunan jäähdystysajastimen kanssa enkä vain millään saanut sitä 
        // toimimaan vaikka katsoin viedeoita uudestaan ja uudestaan, koitin googlata ohjeita ja hyödyntää annettuja linkkejä yms.
        // Samoin en mitenkään löytänyt tietoa Googlesta siitä, miten saan ajastimen alkamaan asetetusta tavoitelämpötilasta.
        // Visual Studio on itselleni aivan uusi ohjelma ja tämänhetkinen kokemukseni koodaamisesta ei vain riittänyt siihen että
        // olisin itsekseni saanut pääteltyä loogisesti ratkaisut. Olen todella yrittänyt parhaani ja harmittaa ihan hirveästi 
        // että epäonnistuin. Tarkoituksena oli tehdä myös ylimääräiset lisätehtävät mutta en koskaan päässyt niihin asti vaikka
        // luulin aloittaneeni projektin hyvissä ajoin. Sain onneksi sentään kaksi kolmesta älytalon osasta toimimaan moitteetta
        // ja niiden kanssa koin ihania onnistumisen tunteita. Jätin kommentointiin yritykseni jäähdytinajastimen koodauksesta sekä 
        // kommentointiin myös yritykseni saada ajastin alkamaan asetetusta tavoitelämpötilasta. Toivottavasti yritykseni huomioidaan 
        // tehtävän arvioinnissa. Koitin laittaa sinulle Teamsissa eilen sunnuntaina viestiä aiheesta mutta et vastannut viestiini.
    }
}
